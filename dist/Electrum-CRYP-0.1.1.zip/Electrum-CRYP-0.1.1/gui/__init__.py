# To create a new GUI, please add its code to this directory.
# Two objects must be passed to the ElectrumGui: config and network
# The Wallet object is instanciated by the GUI

# Notifications about network events are sent to the GUI by using network.register_callback()
